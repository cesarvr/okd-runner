let count = 0
console.log('listening in 8080')
require('http')
    .createServer((req, res) => { 
        res.end(`<HTML> Hello World </HTML>`) 
        console.log(`response:${Date.now()}ms`)
    }).listen(8080)

