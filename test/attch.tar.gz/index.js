const { Ambassador }  = require('node-ambassador')

const HTTP404 = `
    HTTP/1.0 404 File not found
    Server: Sitio 💥
    Date: ${Date()}
    Content-Type: text/html
    Connection: close

    <body>
      <H1>Endpoint Not Found</H1>
      <img src="">
    </body>`



function override_404({service, server}) {
  service.on('http:404', () => console.log('404 Detected!'))
  service.on('http:404', () => server.respond(HTTP404))
}

const TARGET = process.env['TARGET_PORT'] || 8087
const PORT   = process.env['PORT'] || 8080

new Ambassador({port: PORT, target: TARGET})
    .tunnel({override_404})

console.log(`listening for request in ${PORT} and targeting ${TARGET}`)
